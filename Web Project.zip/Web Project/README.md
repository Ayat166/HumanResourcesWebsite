Project name: Human Resources website

the logo is the first page
to signIn use any name and password (P@ssw0rd)
to make it work open folder named project
with Visual studio code 
and write (python manage.py runserver)
 
  
from django.contrib import admin
from .models import GetVecationInfo,Employee
admin.site.register(GetVecationInfo)
admin.site.register(Employee)

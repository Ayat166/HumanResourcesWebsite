from urllib import request
from django.db import models
# Create your models here.

class GetVecationInfo(models.Model):
    name=models.CharField(max_length=100,default='unknown')
    idd=models.CharField(max_length=100,default='0')
    start_date=models.DateField()
    end_date=models.DateField()
    reason=models.TextField(max_length=10000,default='reason')
    def __str__(self):
        return self.reason

class Employee(models.Model):
    username = models.CharField(max_length=20)
    emp_id = models.IntegerField()
    email = models.EmailField()
    address = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    mobile = models.IntegerField()
    DateOfBirth = models.DateField()
    salary = models.CharField(max_length=20)
    number_of_available_vacation_days = models.IntegerField()
    number_of_total_vacation_days = models.IntegerField()
    gender = models.CharField(max_length=20)
    Martial_status = models.CharField(max_length=20)
    position = models.CharField(max_length=20)
    def __str__(self):
        return self.username


    
    
    


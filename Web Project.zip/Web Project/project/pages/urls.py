from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.logo, name='logo'),
    path('Edit', views.Edit, name='Edit'),
    path('Home2', views.Home2, name='Home2'),
    path('EmployeePage', views.EmployeePage, name='EmployeePage'),
    path('login', views.login, name='login'),
    path('main_page', views.main_page, name='main_page'),
    path('ManagerPage', views.ManagerPage, name='ManagerPage'),
    path('addEmployee', views.addEmployee, name='addEmployee'),

    path('orderd_vacation', views.orderd_vacation, name='orderd_vacation'),
    path('vacation_form', views.vacation_form, name='vacation_form'),
    path('delete/<id>', views.delete, name='delete'),
    path('delete_emp/<id>', views.delete_emp, name='delete_emp'),
    path('updatepage/<id>', views.updatepage, name='updatepage'),
    path('EmployeePage/<id>', views.EmployeePage, name='EmployeePage'),
    path('updatepage/delete_emp/<id>', views.delete_emp, name='delete_emp'),
    path('delete_items/<id>/', views.delete_items, name='delete_items'),
    path('upload', views.upload, name='upload'),
    path('delete_vacation/<id>/', views.delete_vacation, name='delete_vacation'),



]

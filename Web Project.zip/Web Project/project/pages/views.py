
import email
from http.client import HTTPResponse
from tkinter.messagebox import NO

from django.http import HttpResponseRedirect
from django.http import HttpResponse
from multiprocessing import context
from turtle import title
from unicodedata import name
from django.shortcuts import render, redirect
from .models import Employee, GetVecationInfo
from .filters import OrderFilter
from .forms import EmployeeForm
from django.http import JsonResponse
# Create your views here.


def logo(request):
    return render(request, 'pages/logo.html')


def addEmp(request):
    return render(request, 'pages/newRegister.html')


def Home2(request):
    return render(request, 'pages/Home2.html')


def Edit(request):
    show_info = Employee.objects.all()
    myFilter = OrderFilter(request.GET, queryset=show_info)
    show_info = myFilter.qs
    context = {'info': show_info, 'myFilter': myFilter}
    return render(request, 'pages/Edit.html', context)


def EmployeePage(request, id):
    Emp = Employee.objects.get(pk=id)
    return render(request, 'pages/EmployeePage.html', {'Emp': Emp})


def login(request):
    return render(request, 'pages/login.html')


def main_page(request):
    return render(request, 'pages/main_page.html')


def ManagerPage(request):
    return render(request, 'pages/ManagerPage.html')


def orderd_vacation(request):
    show_info = GetVecationInfo.objects.all()
    return render(request, 'pages/orderd_vacation.html', {'info': show_info})


def vacation_form(request):

    if request.method == 'POST':
        new_info = GetVecationInfo(
            name=request.POST['name'],
            idd=request.POST['idd'],
            start_date=request.POST['start_date'],
            end_date=request.POST['end_date'],
            reason=request.POST['reason'],
        )
        new_info.save()

    return render(request, 'pages/vacation_form.html')


def delete(request, id):
    dele = GetVecationInfo.objects.get(id=id)
    dele.delete()
    return redirect('orderd_vacation')


def delete_emp(request, id):
    delee = Employee.objects.filter(id=id)
    delee.delete()
    return redirect('Edit')


def updatepage(request, id):
    Emp = Employee.objects.get(pk=id)
    form = EmployeeForm(instance=Emp)
    if request.method == 'POST':
        form = EmployeeForm(request.POST, instance=Emp)
        if form.is_valid():
            form.save()
        return redirect('Edit')
    return render(request, 'pages/updatepage.html', {'form': form})


def delete_items(request, id):
    obj = Employee.objects.get(pk=id)
    context = {}
    if request.method == "POST":
        obj.delete()
        return HttpResponseRedirect("/Edit")

    return render(request, "pages/delete_items.html", context)


def delete_vacation(request, id):
    queryset = GetVecationInfo.objects.get(pk=id)
    if request.method == 'POST':
        queryset.delete()
        return redirect('/orderd_vacation')
    return render(request, 'pages/delete_items.html')


def upload(request):
    if request.method == 'POST':
        return HttpResponse()


def addEmployee(request):
    employee = Employee.objects.all()
    if request.method == 'POST':
        info = Employee(
            username=request.POST['username'],
            emp_id=request.POST['emp_id'],
            DateOfBirth=request.POST['DateOfBirth'],
            password=request.POST['password'],
            email=request.POST['email'],
            mobile=request.POST['mobile'],
            address=request.POST['address'],
            gender=request.POST['gender'],
            Martial_status=request.POST['Martial_status'],
            position=request.POST['position'],
            salary=request.POST['salary'],
            number_of_available_vacation_days=request.POST['number_of_available_vacation_days'],
            number_of_total_vacation_days=request.POST['number_of_total_vacation_days'],
        )

        info.save()
    return render(request, 'pages/newRegister.html', {"employee": employee})

from django.apps import AppConfig


class AjaxpostConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AjaxPost'

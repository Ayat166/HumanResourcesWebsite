function Put(id, body) {
    body = JSON.stringify(body);
    let http = new XMLHttpRequest();

    function callBack() {
        if (4 === http.readyState && (http.status === 201 || http.status === 200)) {
            var responseBody = JSON.parse(http.responseText);
            console.log(responseBody);
        } else if (http.status === 404) {
            console.log("Not Found");
        } else if (http.status === 400) {
            var responseBody = JSON.parse(
                http.responseText ?? '{"error":"Un expectedError"}'
            );
            console.log("Some data is missing");
            console.log(responseBody);
        }
    }
    http.onreadystatechange = callBack;
    http.open("PUT", "http://127.0.0.1:8000/addEmployee/" + id);
    http.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    http.send(body);
}

function Post(body) {
    body = JSON.stringify(body);
    let http = new XMLHttpRequest();

    function callBack() {
        if (4 === http.readyState && (http.status === 201 || http.status === 200)) {
            var responseBody = JSON.parse(http.responseText);
            console.log(responseBody);
        } else if (http.status === 404) {
            console.log("Not Found");
        } else if (http.status === 400) {
            var responseBody = JSON.parse(
                http.responseText ?? '{"error":"Un expectedError"}'
            );
            console.log("Some data is missing");
            console.log(responseBody);
        }
    }
    http.onreadystatechange = callBack;
    http.open("POST", "http://127.0.0.1:8000/addEmployee");
    http.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    http.send(body);
}

function Get() {
    let http = new XMLHttpRequest();

    function callBack() {
        if (4 === http.readyState && (http.status === 201 || http.status === 200)) {
            var responseBody = JSON.parse(http.responseText);
            console.log(responseBody);
        } else if (http.status === 404) {
            console.log("Not Found");
        } else if (http.status === 400) {
            var responseBody = JSON.parse(
                http.responseText ?? '{"error":"Un expectedError"}'
            );
            console.log("Some data is missing");
            console.log(responseBody);
        }
    }
    http.onreadystatechange = callBack;
    http.open("GET", "http://127.0.0.1:8000/addEmployee");
    http.send();
}

function PostEmployee() {
    const testEmployee = {
        name: "Name",
        email: "email@gmail.com",
        phoneNumber: "01094046206",
        dateOfBirth: "2006-07-21",
        gender: "Male",
        maritalStatus: "Married",
        address: "6th of october city",
        availableVacations: 100,
        salary: 10000,
    };

    Post(testEmployee);
}

function UpdateEmployee() {
    const testEmployee = {
        name: "Name 2",
        email: "email2@gmail.com",
        phoneNumber: "2",
        dateOfBirth: "2006-07-21",
        gender: "Male 2",
        maritalStatus: "Married 2",
        address: "12th of october city",
        availableVacations: 5,
        salary: 4444,
    };

    Put(10, testEmployee);
}
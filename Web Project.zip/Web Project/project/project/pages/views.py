from django.shortcuts import render
# Create your views here.
def logo(request):
    return render(request,'pages/logo.html')

def Home2(request):
    return render(request,'pages/Home2.html')

def Edit(request):
    return render(request,'pages/Edit.html')

def EmployeePage(request):
    return render(request,'pages/EmployeePage.html')

def login(request):
    return render(request,'pages/login.html')

def main_page(request):
    return render(request,'pages/main_page.html')

def ManagerPage(request):
    return render(request,'pages/ManagerPage.html')

def newRegister(request):
    return render(request,'pages/newRegister.html')

def orderd_vacation(request):
    return render(request,'pages/orderd_vacation.html')

def vacation_form(request):
    return render(request,'pages/vacation_form.html')
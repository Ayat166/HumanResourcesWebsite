

function checkValidations() {

   
 
    let usernameLength = document.getElementById('userName').value.length;
    let emailLength = document.getElementById('mail').value.length;
    let passwordLength = document.getElementById('password').value.length;
    let mobilenumber = document.getElementById('mobile').value.length;
    var c=0;
    if(usernameLength == 0 || emailLength ==  0 ){

        alert("please enter the empty feilds");
        document.getElementById('submitbutton').disabled = false; 
        c=c+1;
        return false ; 
        
    }
    if(passwordLength <8){
        alert("password must be at least 8 chracters ");
        document.getElementById('password').focus(); 
        c=c+1;
        return false ; 

    }
    if(mobilenumber<11)
    {
        alert("Enter valid mobile number "); 
        c=c+1;
    }
    if(c==0)
    {
        setTimeout(function() {window.location = "Home2" });
    }
    return true ; 
   
}
function promptPassword()
{
   
let pwd =document.getElementById('pww').value;

while (pwd != 'P@ssw0rd'){
alert("Login is incorrect");
pwd = prompt ("Enter your Password: ");
}
setTimeout(function() {window.location = "Home2" });
alert("Password is correct, you are allowed to enter the site");

 

return true ; 
}
function onDelete() {
    let confirmation = document.getElementById("confirmation")
    if(!confirmation.classList.contains("model-open")){
        confirmation.classList.add("model-open");
    }
}
function onCancel(){
    let confirmation = document.getElementById("confirmation")
    confirmation.classList.remove("model-open");
}
function onConfirm(){
    onCancel();
}
function success()
{
    alert("successful");
}
